@extends('template')


@section('css')
@endsection

@section('content')
<h1>ini dashboard Fakultas</h1>
@endsection