@extends('template')


@section('css')
@endsection

@section('content')
<h1>Selamat Datang Admin Febi</h1>
@endsection