        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by <a href="https://tipd.iainkendari.ac.id/"
                        target="_blank">TIPD IAIN KENDARI</a> 2021</p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->