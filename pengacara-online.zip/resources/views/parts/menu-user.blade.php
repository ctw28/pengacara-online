<li><a class="has-arrow ai-icon" href="{{route('user.kegiatan.index')}}" aria-expanded="false">
        <i class="flaticon-050-info"></i>
        <span class="nav-text">Kegiatan</span>
    </a>
</li>