@yield('css')
<link href="{{asset('/')}}vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
<link href="{{asset('/')}}css/style.css" rel="stylesheet">