<?php echo $__env->yieldContent('css'); ?>
<link href="<?php echo e(asset('/')); ?>vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
<link href="<?php echo e(asset('/')); ?>css/style.css" rel="stylesheet"><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/parts/css.blade.php ENDPATH**/ ?>