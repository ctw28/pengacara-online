

<?php $__env->startSection('css'); ?>
<style>
.insert {
    cursor: pointer;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <h4 class="">Info Kegiatan:</h4>
        <p><?php echo e($data['kegiatan']->kegiatan_nama); ?></p>

    </div>
</div>

<div class="card">
    <div class="card-header">
        <h4 class="card-title">Data Anggota</h4>
        <a href="<?php echo e(route('user.kegiatan.jabatan.peserta.add',[$data['kegiatan']->id,$data['kegiatanJabatan']->id])); ?>"
            class="btn btn-info">Manage
            Anggota</a>
    </div>
    <div class="card-body">
        <h4 class="">Info Jabatan:</h4>
        <p><?php echo e($data['kegiatanJabatan']->mKegiatanJabatan->kegiatan_jabatan_nama); ?></p>
        <div class="table-responsive">
            <table class="table table-responsive-sm">
                <thead>
                    <tr class="text-center">
                        <th>#</th>
                        <th>NIP</th>
                        <th>Nama</th>
                        <th>Golongan</th>
                    </tr>
                </thead>
                <tbody id="list-data-anggota" class="text-center">
                    <?php $__currentLoopData = $data['dataPeserta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index+1); ?></td>
                        <td><?php echo e($row->nip); ?></td>
                        <td><?php echo e($row->nama); ?></td>
                        <td><?php echo e($row->golongan); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/user/kegiatan-jabatan-peserta-list.blade.php ENDPATH**/ ?>