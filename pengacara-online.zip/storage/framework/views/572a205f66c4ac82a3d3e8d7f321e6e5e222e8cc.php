<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
        <i class="flaticon-025-dashboard"></i>
        <span class="nav-text">Dashboard</span>
    </a>
</li>
<li><a class="has-arrow ai-icon" href="<?php echo e(route('user.kegiatan.index')); ?>" aria-expanded="false">
        <i class="flaticon-050-info"></i>
        <span class="nav-text">Kegiatan</span>
    </a>
</li><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/parts/menu-user.blade.php ENDPATH**/ ?>