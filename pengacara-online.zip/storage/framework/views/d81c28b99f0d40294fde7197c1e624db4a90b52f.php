<!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Dompet : Payment Admin Template" />
    <meta property="og:title" content="Dompet : Payment Admin Template" />
    <meta property="og:description" content="Dompet : Payment Admin Template" />
    <meta property="og:image" content="https://dompet.dexignlab.com/xhtml/social-image.png" />
    <meta name="format-detection" content="telephone=no">

    <!-- PAGE TITLE HERE -->
    <title>Dompet : Payment Admin Template</title>

    <!-- FAVICONS ICON -->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <link href="<?php echo e(asset('/')); ?>css/style.css" rel="stylesheet">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
                                    <h3 class="text-center mb-4">Hai, <?php echo e(auth()->user()->name); ?></h3>
                                    <h4 class="text-center mb-4">silahkan tentukan Tahun Anggaran dahulu</h4>
                                    <form action="index.html">
                                        <div class="mb-3">
                                            <!-- <label class="mb-1"><strong>Pilih Tahun Anggaran</strong></label> -->
                                            <select class="default-select form-control wide mb-3" name="tahun_anggaran"
                                                required>
                                                <option value="">Pilih Tahun Anggaran</option>
                                                <?php $__currentLoopData = $tahunAnggaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($tahun->id); ?>"><?php echo e($tahun->tahun_anggaran); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select> <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary btn-block">Pilih</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
    <!-- Common JS -->
    <script src="<?php echo e(asset('/')); ?>vendor/global/global.min.js"></script>
    <!-- Custom script -->
    <script src="<?php echo e(asset('/')); ?>vendor/dlabnav/dlabnav.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/custom.min.js"></script>
    <script src="<?php echo e(asset('/')); ?>js/dlabnav-init.js"></script>

</body>

</html><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/user/pilih-tahun-ajar.blade.php ENDPATH**/ ?>