<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
        <i class="flaticon-025-dashboard"></i>
        <span class="nav-text">Dashboard</span>
    </a>
</li>
<li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
        <i class="flaticon-086-star"></i>
        <span class="nav-text">Referensi Data</span>
    </a>
    <ul aria-expanded="false">
        <li><a href="<?php echo e(route('admin.tahun.anggaran')); ?>">Tahun Anggaran</a></li>
    </ul>
</li>
<li><a class="has-arrow ai-icon" href="#" aria-expanded="false">
        <i class="flaticon-050-info"></i>
        <span class="nav-text">Pengaturan Pejabat</span>
    </a>
</li>
<li><a class="has-arrow ai-icon" href="<?php echo e(route('kwitansi')); ?>" aria-expanded="false">
        <i class="flaticon-041-graph"></i>
        <span class="nav-text">Pengaturan Fakultas</span>
    </a>
</li><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/parts/menu-admin.blade.php ENDPATH**/ ?>