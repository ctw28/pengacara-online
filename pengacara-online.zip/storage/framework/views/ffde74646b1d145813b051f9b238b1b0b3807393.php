

<?php $__env->startSection('content'); ?>
<div class="col-xl-12 col-lg-12">
    <div class="card">
        <div class="card-body">
            <h4 class="">Info Kegiatan:</h4>
            <p><?php echo e($data['kegiatan']->kegiatan_nama); ?></p>

        </div>
    </div>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Daftar Jenis Pembayaran</h4>
            <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#basicModal">+ Tambah
                Jenis Pembayaran</button>
            <!-- Modal -->
            <div class="modal fade" id="basicModal">
                <div class="modal-dialog  modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Form Tambah Jenis Pembayaran</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal">
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="basic-form">
                                <form action="<?php echo e(route('user.kegiatan.jabatan.bayar.setup.store')); ?>" method="post">
                                    <div class="row">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="kegiatan_jabatan_id"
                                            value="<?php echo e($data['kegiatanJabatan']->id); ?>">
                                        <div class="mb-3 col-md-3">
                                            <label class="form-label">Jenis Pembayaran</label>
                                            <select id="inputState" name="m_bayar_kategori_id"
                                                class="default-select form-control wide">
                                                <option selected>Pilih Jenis</option>
                                                <?php $__currentLoopData = $data['bayarKategori']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($row->id); ?>"><?php echo e($row->bayar_nama); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-3">
                                            <label class="form-label">Honor</label>
                                            <input type="text" id="honor" name="honor" class="form-control"
                                                placeholder="Rp......">
                                        </div>
                                        <div class="mb-3 col-md-3">
                                            <label class="form-label">Jumlah Satuan</label>
                                            <input type="number" class="form-control" placeholder="" name="jumlah">
                                        </div>
                                        <div class="mb-3 col-md-3">
                                            <label>Satuan</label>
                                            <select id="inputState" class="default-select form-control wide"
                                                name="master_satuan_id">
                                                <option selected>Pilih Satuan</option>
                                                <<?php $__currentLoopData = $data['satuan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($row->id); ?>">
                                                    <?php echo e($row->master_satuan_singkatan); ?> - <?php echo e($row->master_satuan_nama); ?>

                                                    </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                            </div>
                            <button type="submit" class="btn btn-primary">Tambah</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Modal -->
        </div>
        <div class="card-body">
            <!-- <h6>Info Jabatan</h6> -->
            <h6>Nama Jabatan : <?php echo e($data['kegiatanJabatan']->MKegiatanJabatan->kegiatan_jabatan_nama); ?></h6>

            <div class="table-responsive">
                <table class="table table-responsive-sm">
                    <thead>
                        <tr class="text-center">
                            <th>#</th>
                            <th>Jenis Pembayaran</th>
                            <th>Honor</th>
                            <th>Jumlah</th>
                            <th>Satuan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data['kegiatanBayarJabatanData']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($index+1); ?></td>
                            <td><?php echo e($row->mBayarKategori->bayar_nama); ?></td>
                            <td>Rp.
                                <?php echo e(number_format($row->kegiatanBayarJabatanAtur->honor, 0, ',','.')); ?></td>
                            <td><?php echo e($row->kegiatanBayarJabatanAtur->jumlah); ?></td>
                            <td>
                                <?php echo e($row->kegiatanBayarJabatanAtur->masterSatuan->master_satuan_singkatan); ?> /
                                <?php echo e($row->kegiatanBayarJabatanAtur->masterSatuan->master_satuan_nama); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn btn-danger light sharp" data-bs-toggle="dropdown"
                                        aria-expanded="false">
                                        <svg width="20px" height="20px" viewBox="0 0 24 24" version="1.1">
                                            <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                                <rect x="0" y="0" width="24" height="24"></rect>
                                                <circle fill="#000000" cx="5" cy="12" r="2"></circle>
                                                <circle fill="#000000" cx="12" cy="12" r="2"></circle>
                                                <circle fill="#000000" cx="19" cy="12" r="2"></circle>
                                            </g>
                                        </svg>
                                    </button>
                                    <div class="dropdown-menu" style="margin: 0px;">
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('user.kegiatan.jabatan.bayar.setup.destroy',$row->id)); ?>"
                                            onclick="return confirm('Yakin?')"><i
                                                class="las la-times-circle text-danger scale5 me-3"></i>Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>


        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
const locale = "de-DE";
const numberFormat = new Intl.NumberFormat(locale, {
    style: "decimal",
    maximumFractionDigits: 0,
    minimumFractionDigits: 0
});
const onlyChars = new RegExp(/^.$/)
const onlyNumbers = new RegExp(/\d/);
document.querySelector("#honor")
    .addEventListener("keydown", function(e) {
        if (onlyNumbers.test(e.key)) {
            e.preventDefault()
            e.target.value = numberFormat.format(e.target.value.replace(/\./g, '') + e.key)
        } else if (onlyChars.test(e.key) &&
            !e.getModifierState('Meta') &&
            !e.getModifierState('Ctrl')) {
            e.preventDefault()
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/user/kegiatan-jabatan-bayar-setup.blade.php ENDPATH**/ ?>