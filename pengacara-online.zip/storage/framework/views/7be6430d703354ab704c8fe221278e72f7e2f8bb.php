<!--**********************************
        Scripts
    ***********************************-->
<!-- Required vendors -->
<script src="<?php echo e(asset('/')); ?>vendor/global/global.min.js"></script>
<script src="<?php echo e(asset('/')); ?>vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
<?php echo $__env->yieldContent('js'); ?>
<script src="<?php echo e(asset('/')); ?>js/custom.min.js"></script>
<script src="<?php echo e(asset('/')); ?>js/dlabnav-init.js"></script>
<!-- <script>
jQuery(document).ready(function() {
    setTimeout(function() {
        dezSettingsOptions.version = 'dark';
        new dezSettings(dezSettingsOptions);
    }, 500)
});
</script> --><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/parts/script.blade.php ENDPATH**/ ?>