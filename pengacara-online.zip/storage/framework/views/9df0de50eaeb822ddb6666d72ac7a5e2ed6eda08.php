

<?php $__env->startSection('content'); ?>
<div class="card-bx bg-blue">
    <img class="pattern-img" src="<?php echo e(asset('/')); ?>images/pattern/pattern6.png" alt="">
    <div class="card-info text-white" style="padding:0">
        <!-- <img src="<?php echo e(asset('/')); ?>images/pattern/circle.png" alt=""> -->
        <h3 class="text-yellow card-balance"><?php echo e($data['kegiatan']->kegiatan_nama); ?></h3>
        <span class="fs-18">Sesi Pembayaran :
            <?php echo e(\Carbon\Carbon::parse($data['pembayaran']->kegiatan_pembayaran_tanggal)->format('d M Y')); ?></span>

    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h4 class="card-title">Pembayaran Ampra</h4>
        <button id="manage" type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal"
            data-bs-target="#basicModal">
            Tambah Pembayaran Ampra</button>
        <!-- Modal -->
        <div class="modal fade" id="basicModal">
            <div class="modal-dialog  modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Pilih Jenis Pembayaran</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal">
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="table-responsive">
                            <form
                                action="<?php echo e(route('kegiatan.ampra.add',[$data['kegiatan']->id,$data['pembayaran']->id])); ?>"
                                method="post">
                                <table class="table table-hover table-striped table-responsive-md">
                                    <thead>
                                        <tr>
                                            <th style="width:50px;">
                                                <div class="form-check custom-checkbox checkbox-success check-lg me-3">
                                                    <input type="checkbox" class="form-check-input" id="checkAll">
                                                    <label class="form-check-label" for="checkAll"></label>
                                                </div>
                                            </th>
                                            <th><strong>Jabatan</strong></th>
                                            <th><strong>Jenis Pembayaran</strong></th>
                                            <th><strong>Honor</strong></th>
                                            <th><strong>Jumlah</strong></th>
                                            <th><strong>Satuan</strong></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php echo csrf_field(); ?>
                                        <?php $__currentLoopData = $data['bayarJabatan']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $row->kegiatanBayarJabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <div class="form-check custom-checkbox checkbox-success check-lg me-3">
                                                    <input type="checkbox" class="form-check-input" id="customCheckBox2"
                                                        name="kegiatan_bayar_jabatan_id[]" value="<?php echo e($row2->id); ?>">
                                                    <label class="form-check-label" for="customCheckBox2"></label>
                                                </div>
                                            </td>
                                            <td><?php echo e($row->mKegiatanJabatan->kegiatan_jabatan_nama); ?></td>
                                            <td><?php echo e($row2->mBayarKategori->bayar_nama); ?></td>
                                            <td><?php echo e($row2->kegiatanBayarJabatanAtur->honor); ?></td>
                                            <td><?php echo e($row2->kegiatanBayarJabatanAtur->jumlah); ?></td>
                                            <td><?php echo e($row2->kegiatanBayarJabatanAtur->masterSatuan->master_satuan_nama); ?>

                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <button type="submit" class="btn btn-primary">Tambah Pembayaran</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Modal -->
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-responsive-sm">
                <thead>
                    <tr class="text-center">
                        <th>#</th>
                        <th>Jabatan</th>
                        <th>Jenis Pembayaran</th>
                        <th>Honor</th>
                        <th>Jumlah</th>
                        <th>Satuan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody id="list-data-anggota" class="text-center">
                    <?php $__currentLoopData = $data['pembayaranSesi']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index+1); ?></td>
                        <td><?php echo e($row->kegiatanBayarJabatan->kegiatanJabatan->mKegiatanJabatan->kegiatan_jabatan_nama); ?>

                        </td>
                        <td><?php echo e($row->kegiatanBayarJabatan->mBayarKategori->bayar_nama); ?></td>
                        <td><?php echo e($row->kegiatanBayarJabatan->kegiatanBayarJabatanAtur->honor); ?></td>
                        <td><?php echo e($row->kegiatanBayarJabatan->kegiatanBayarJabatanAtur->jumlah); ?></td>
                        <td><?php echo e($row->kegiatanBayarJabatan->kegiatanBayarJabatanAtur->masterSatuan->master_satuan_nama); ?>

                        </td>
                        <td><a class="btn btn-info btn-xs" href="<?php echo e(route('kegiatan.ampra.set',[
                            $data['kegiatan']->id,
                            $data['pembayaran']->id,
                            $row->id
                            ])); ?>">Bayar Ampra</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Rigo Files\Development\pengacara-online\resources\views/user/kegiatan-ampra-index.blade.php ENDPATH**/ ?>