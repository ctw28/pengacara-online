<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class KegiatanPesertaController extends Controller
{
    //
}
